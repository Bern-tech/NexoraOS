# NEXORA OS — Android Launcher Prototype

A futuristic Android launcher prototype built with Kotlin + Jetpack Compose.

## What is included
- Home screen with live clock/date
- Live battery percentage
- Real storage usage
- Network status
- Dynamic app drawer from installed launchable apps
- App search
- Launch installed apps
- Android HOME intent so it can be selected as the default launcher
- Dark cyan tech visual system

## Open
Open this folder in Android Studio and let Gradle sync. Then run on an Android phone/emulator.

## Note
This is a prototype launcher, not a replacement for Android itself. Some system UI elements remain controlled by Android.
