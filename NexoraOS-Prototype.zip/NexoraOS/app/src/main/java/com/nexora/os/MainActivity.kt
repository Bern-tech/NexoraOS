package com.nexora.os

import android.app.*
import android.content.*
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.os.StatFs
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFF05070A)
private val Panel = Color(0xFF0B1016)
private val Cyan = Color(0xFF20E7FF)
private val Muted = Color(0xFF7B8997)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { NexoraApp() } }
}

data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

@Composable fun NexoraApp() {
    val context = LocalContext.current
    var showApps by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val apps = remember { loadApps(context) }
    val battery = rememberBattery(context)
    val storage = rememberStorage()
    val network = rememberNetwork(context)
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val clock = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE // dd MMM yyyy", Locale.getDefault()).format(now).uppercase(Locale.getDefault())

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            if (!showApps) {
                HomeScreen(clock, date, battery, storage, network, onApps = { showApps = true })
            } else {
                AppsScreen(apps.filter { it.label.contains(search, true) }, search, { search = it }, { showApps = false }, context)
            }
        }
    }
}

@Composable private fun HomeScreen(clock: String, date: String, battery: Int, storage: Pair<Long, Long>, network: String, onApps: () -> Unit) {
    val pulse by rememberInfiniteTransition(label="p").animateFloat(0.65f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label="p")
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("NEXORA OS", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("SYSTEM 01", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp) }
                Text("● ONLINE", color = Cyan.copy(alpha=pulse), fontSize=11.sp, letterSpacing=1.sp)
            }
            Spacer(Modifier.height(42.dp))
            Text(clock, color=Color.White, fontSize=64.sp, fontWeight=FontWeight.ExtraLight, fontFamily=FontFamily.Monospace)
            Text(date, color=Muted, fontSize=11.sp, letterSpacing=1.4.sp)
        }
        Column {
            Text("SYSTEM STATUS", color=Cyan, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp)
            Spacer(Modifier.height(10.dp))
            StatusCard("BATTERY", "$battery%", Icons.Default.BatteryFull)
            StatusCard("STORAGE", formatBytes(storage.first)+" / "+formatBytes(storage.second), Icons.Default.Storage)
            StatusCard("NETWORK", network, Icons.Default.Wifi)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                TechButton("APP DRAWER", Icons.Default.Apps, Modifier.weight(1f), onApps)
                TechButton("SETTINGS", Icons.Default.Settings, Modifier.weight(1f)) { }
            }
            Spacer(Modifier.height(12.dp))
            Text("NEXORA // SYSTEM READY", color=Muted, fontSize=10.sp, modifier=Modifier.fillMaxWidth(), textAlign=TextAlign.Center, letterSpacing=2.sp)
        }
    }
}

@Composable private fun StatusCard(title: String, value: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().padding(vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
        Icon(icon, null, tint=Cyan, modifier=Modifier.size(18.dp)); Spacer(Modifier.width(12.dp)); Text(title, color=Muted, fontSize=11.sp, modifier=Modifier.weight(1f), letterSpacing=1.sp); Text(value, color=Color.White, fontSize=12.sp, fontFamily=FontFamily.Monospace)
    }
}

@Composable private fun TechButton(label:String, icon:ImageVector, modifier:Modifier, action:()->Unit) {
    Button(onClick=action, modifier=modifier.height(52.dp), shape=RoundedCornerShape(10.dp), colors=ButtonDefaults.buttonColors(containerColor=Panel, contentColor=Cyan), border=BorderStroke(1.dp, Cyan.copy(alpha=.25f))) { Icon(icon,null,Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(label,fontSize=10.sp,letterSpacing=1.sp) }
}

@Composable private fun AppsScreen(apps:List<AppEntry>, search:String, setSearch:(String)->Unit, back:()->Unit, context:Context) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { IconButton(back){ Icon(Icons.Default.ArrowBack,null,tint=Cyan) }; Text("APPLICATION MATRIX",color=Cyan,fontSize=15.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp) }
        OutlinedTextField(search,setSearch,Modifier.fillMaxWidth().padding(vertical=10.dp),singleLine=true,placeholder={Text("SEARCH APPLICATIONS",fontSize=11.sp)},leadingIcon={Icon(Icons.Default.Search,null)},colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan, unfocusedBorderColor=Muted, focusedTextColor=Color.White, unfocusedTextColor=Color.White))
        LazyVerticalGrid(columns=GridCells.Fixed(4), verticalArrangement=Arrangement.spacedBy(18.dp), horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxSize()) {
            items(apps, key={it.packageName}) { app -> AppTile(app){ launch(context,app.packageName) } }
        }
    }
}

@Composable private fun AppTile(app:AppEntry, click:()->Unit) {
    Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.clickable{click()}) { AndroidIcon(app.icon); Spacer(Modifier.height(6.dp)); Text(app.label, color=Color.White, fontSize=10.sp, maxLines=1, textAlign=TextAlign.Center) }
}
@Composable private fun AndroidIcon(drawable:android.graphics.drawable.Drawable) { androidx.compose.foundation.Image(androidx.compose.ui.graphics.asImageBitmap(drawableToBitmap(drawable)), null, Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))) }
private fun drawableToBitmap(d:android.graphics.drawable.Drawable): android.graphics.Bitmap { val b=android.graphics.Bitmap.createBitmap(96,96,android.graphics.Bitmap.Config.ARGB_8888); val c=android.graphics.Canvas(b); d.setBounds(0,0,c.width,c.height); d.draw(c); return b }
private fun loadApps(c:Context):List<AppEntry> { val pm=c.packageManager; val i=Intent(Intent.ACTION_MAIN).apply{addCategory(Intent.CATEGORY_LAUNCHER)}; return pm.queryIntentActivities(i,0).map{AppEntry(it.loadLabel(pm).toString(),it.activityInfo.packageName,it.loadIcon(pm))}.distinctBy{it.packageName}.sortedBy{it.label.lowercase()} }
private fun launch(c:Context,p:String){ c.packageManager.getLaunchIntentForPackage(p)?.let{c.startActivity(it)} }

@Composable private fun rememberBattery(c:Context):Int { var b by remember{mutableIntStateOf(0)}; DisposableEffect(Unit){val r=object:BroadcastReceiver(){override fun onReceive(x:Context?,i:Intent?){b=i?.getIntExtra(BatteryManager.EXTRA_LEVEL,0)?:0}}; val f=IntentFilter(Intent.ACTION_BATTERY_CHANGED); c.registerReceiver(r,f); onDispose{c.unregisterReceiver(r)}}; return b }
@Composable private fun rememberStorage():Pair<Long,Long>{ val s=remember{StatFs(Environment.getDataDirectory().path)}; val total=s.totalBytes; val free=s.availableBytes; return total-free to total }
@Composable private fun rememberNetwork(c:Context):String { var n by remember{mutableStateOf("OFFLINE")}; LaunchedEffect(Unit){while(true){val cm=c.getSystemService(ConnectivityManager::class.java); val caps=cm.getNetworkCapabilities(cm.activeNetwork); n=when{caps==null->"OFFLINE";caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"WI-FI";caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"MOBILE";else->"ONLINE"};delay(3000)}};return n }
private fun formatBytes(v:Long):String { val gb=v/1024.0/1024/1024; return String.format(Locale.US,"%.1f GB",gb) }
